# .First.lib <- function(libname, pkgname) {
#    library.dynam("CNORode", pkgname, libname)
# }
