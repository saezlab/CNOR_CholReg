#include <math.h>
#include <stdio.h>
#include <stdlib.h>

double linear_transfer_function(double x,double n,double k)
{
	return(x);
}
