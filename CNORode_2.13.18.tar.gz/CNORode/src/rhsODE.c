
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <cvodes/cvodes.h>          /* prototypes for CVODES fcts. and consts. */
#include <sundials/sundials_types.h> /* definition of type realtype */
#include "CNOStructure.h"
#include <nvector/nvector_serial.h>/* serial N_Vector types, fcts., and macros */

#define min(a, b) (((a) < (b)) ? (a) : (b))
#define max(a, b) (((a) > (b)) ? (a) : (b))

#define Ith(v,i) ( NV_DATA_S(v)[i] )

int rhsODE(realtype t, N_Vector y, N_Vector ydot, void *data)
{
		int i,j,k;
		CNOStructure* myData=(CNOStructure*) data;
	    int countPar=0;
	    double tempProd;
		double kHill,nHill;
	    double hillFuncValues[(*myData).maxNumInputs];
	    int countState=0;
	    
	    //Indexing in C goes from 0 to N-1 from model$namesSpecies 
	    int CholMedia_index=0, Input05_index=1, CholER_index=4, LDLR_index=7, NPC1_index=8, atorvastatin_index = 10, P04035_index=11, 
	      ACAT2act_index=13, Acetyl_CoA_index=14, Acetoacetyl_CoA_index=15, HMGCS1act_index=17, HMG_CoA_index=18, 
	      Mevalonate_index=19;
	    double CholMedia, CholER, LDLR, NPC1, Input05, Acetyl_CoA, ACAT2act,
	    Acetoacetyl_CoA, HMGCS1act, HMG_CoA, Mevalonate, atorvastatin, P04035,
	    dCholER, dAcetyl_CoA, dAcetoacetyl_CoA, dHMG_CoA, dMevalonate;
	    double k1,k2,k3,k4,k5,k6,k7,k8,kM4,kIatorvastatin, 
	    tauAcetyl_CoA, tauAcetoacetyl_CoA, tauMevalonate, tauCholER, tauHMG_CoA;
	    
	    //Rprintf("\nv160709_1\n");

	    //Loop through every column j in the Graph adjacency matrix
	    for (j = 0; j <(*myData).nRows; j++)
	    {
	        if((*myData).isState[j])
	        {
	          // hillFuncValues= (double*)malloc((*myData).numInputs[j]*sizeof(double));
	           Ith(ydot,countState)=0;
	           for (i = 0; i < (*myData).numInputs[j]; ++i)
	           {
	        		  nHill=(*myData).odeParameters[countPar++];
	        		  kHill=(*myData).odeParameters[countPar++];
	        		  
	        		  if(j==14){
	        		    if(i==0){
	        		      k1=kHill;
	        		      //Rprintf("k1index=%d\n",countPar);
          		    }
	        		  }
	        		  
	        		  if(j==15){
	        		    if(i==0){
	        		      k7=kHill;
	        		      //Rprintf("k7index=%d\n",countPar);
	        		    }
	        		    if(i==1){
	        		      k2=kHill;
	        		      //Rprintf("k2index=%d\n",countPar);
	        		      tauAcetoacetyl_CoA=nHill;
	        		      //Rprintf("tauAcetoacetyl_CoA_index=%d\n",countPar-1);
          		    }
	        		  }
	        		  if(j==18){
	        		    if(i==0){
	        		      tauHMG_CoA=kHill;
	        		      //Rprintf("tauHMG_CoA_index=%d\n",countPar);
 	        		    }
	        		    if(i==1){
	        		      k3=kHill;
	        		      //Rprintf("k3index=%d\n",countPar);
	        		    }
	        		    if(i==2){
	        		      tauAcetyl_CoA=kHill;
	        		      //Rprintf("tauAcetyl_CoA_index=%d\n",countPar);
	        		    }
	        		    
	        		  }
	        		  if(j==19){
	        		    if(i==0){
	        		      kIatorvastatin=kHill;
	        		      //Rprintf("kIatorvastatinindex=%d\n",countPar);
	        		      tauMevalonate=nHill;
	        		      //Rprintf("tauMevalonate_index=%d\n",countPar-1);
	        		    }
	        		    if(i==2){
	        		      k4=kHill;
	        		      //Rprintf("k4index=%d\n",countPar);
	        		      kM4=nHill;
	        		      //Rprintf("kM4index=%d\n",countPar-1);
	        		    }
	        		  }
	        		  if(j==4){
	        		    if(i==0){
	        		      k6=kHill;
	        		      //Rprintf("k6index=%d\n",countPar);
	        		      tauCholER=nHill;
	        		      //Rprintf("tauCholER_index=%d\n",countPar-1);
	        		    }
	        		    if(i==1){
	        		      k8=kHill;
	        		      //Rprintf("k8index=%d\n",countPar);
	        		    }
	        		    if(i==3){
	        		      k5=kHill;
	        		      //Rprintf("k5index=%d\n",countPar);
	        		    }
	        		  }

	        		  
	        		   if((*myData).isState[(*myData).input_index[j][i]])
	        		   {
	        			   hillFuncValues[i]=
	        					   (*myData).transfer_function(Ith(y,(*myData).state_index[(*myData).input_index[j][i]]),nHill,kHill);
	        		   }
	        		   else
	        		   {
	        			   hillFuncValues[i]=
	        					   (*myData).transfer_function((*myData).state_array[(*myData).input_index[j][i]],nHill,kHill);
	        		   }
	           }

	           //For every bit in the truth table
	           for (i = 0; i < (*myData).count_bits[j]; ++i)
	           {
	        	   //if ((*myData).truthTables[j][i])
	        	   //{
	        		   tempProd=1;
	        		   for (k = 0; k < (*myData).numInputs[j]; k++)
	        		   {
	        			   if(!(*myData).support_truth_tables[j][(*myData).truth_tables_index[j][i]][k])
	        			   {
	        				   tempProd*=(1-hillFuncValues[k]);
	        			   }
	        			   else tempProd*=hillFuncValues[k];
	        		   }

	        		   Ith(ydot,countState)+=tempProd;
	        	  // }
	           }
	           
	           Ith(ydot,countState)=((1-(*myData).inhibitor_array[j])*Ith(ydot,countState)-Ith(y,countState))*(*myData).odeParameters[countPar++];
	           
	           //Ith(ydot,countState)=
	        	//	   (Ith(ydot,countState)-Ith(y,countState))
	        	//	   	   *(*myData).odeParameters[countPar++]
	        	//	   	   	   *(1-(*myData).inhibitor_array[j]);

	           countState++;
	           
	           if(CholMedia_index==j)CholMedia_index=countState-1;
	           if(CholER_index==j)CholER_index=countState-1;
	           if(LDLR_index==j)LDLR_index=countState-1;
	           if(NPC1_index==j)NPC1_index=countState-1;
	           if(Input05_index==j)Input05_index=countState-1;
	           if(Acetyl_CoA_index==j)Acetyl_CoA_index=countState-1;
	           if(ACAT2act_index==j)ACAT2act_index=countState-1;
	           if(Acetoacetyl_CoA_index==j)Acetoacetyl_CoA_index=countState-1;
	           if(HMGCS1act_index==j)HMGCS1act_index=countState-1;
	           if(HMG_CoA_index==j)HMG_CoA_index=countState-1;
	           if(Mevalonate_index==j)Mevalonate_index=countState-1;
	           if(P04035_index==j)P04035_index=countState-1;
	           if(atorvastatin_index==j)atorvastatin_index=countState-1;
	           
	        }
	        
	    }
	    
	    CholMedia=Ith(y,CholMedia_index);
	    CholER=Ith(y,CholER_index);
	    LDLR=Ith(y,LDLR_index);
	    NPC1=Ith(y,NPC1_index);
	    Input05=Ith(y,Input05_index);
	    Acetyl_CoA=Ith(y,Acetyl_CoA_index);
	    HMGCS1act=Ith(y,HMGCS1act_index);
	    Acetoacetyl_CoA=Ith(y,Acetoacetyl_CoA_index);
	    ACAT2act=Ith(y,ACAT2act_index);
	    HMG_CoA=Ith(y,HMG_CoA_index);
	    P04035=Ith(y,P04035_index);
	    Mevalonate=Ith(y,Mevalonate_index);
	    atorvastatin=Ith(y,atorvastatin_index);

	    
	    dAcetyl_CoA=(k1*Input05 - k2*ACAT2act*pow(Acetyl_CoA,2) - k3*HMGCS1act*Acetyl_CoA*Acetoacetyl_CoA-k7*Acetyl_CoA)*tauAcetyl_CoA;
	    dAcetoacetyl_CoA=(k2*ACAT2act*pow(Acetyl_CoA,2) - k3*HMGCS1act*Acetyl_CoA*Acetoacetyl_CoA)*tauAcetoacetyl_CoA;
	    dHMG_CoA=(k3*HMGCS1act*Acetyl_CoA*Acetoacetyl_CoA-k4*P04035*HMG_CoA*(1-(pow(atorvastatin,kM4)/(pow(kIatorvastatin,kM4) + pow(atorvastatin,kM4)))))*tauHMG_CoA; 
	    dMevalonate=(k4*P04035*HMG_CoA/(kM4+HMG_CoA+((kM4*atorvastatin)/kIatorvastatin))-k5*Mevalonate)*tauMevalonate;
      dCholER=(k6*CholMedia*LDLR*NPC1+k5*Mevalonate-k8*CholER)*tauCholER;

	    Ith(ydot,Acetyl_CoA_index)=dAcetyl_CoA;
	    Ith(ydot,Acetoacetyl_CoA_index)=dAcetoacetyl_CoA;
	    Ith(ydot,HMG_CoA_index)=dHMG_CoA;
	    Ith(ydot,Mevalonate_index)=dMevalonate;
	    Ith(ydot,CholER_index)=dCholER;


	    return(0);
	}

